import locale
import json
import logging
import subprocess
import re
from ruxit.api.snapshot import pgi_name
from ruxit.api.base_plugin import BasePlugin
from ruxit.api.selectors import FromPluginSelector
from ruxit.api.data import PluginMeasurement
from ruxit.api.exceptions import ConfigException
from concurrent.futures import ThreadPoolExecutor
import time
from enum import Enum
from datetime import datetime
import os

logger = logging.getLogger(__name__)

# for security reasons, this plugin can only execute scripts that are into that specific directory, so that no other system script can be run
linux_script_directory = "/opt/dynatrace/oneagent/scripts/"
windows_script_directory = "C:\\ProgramData\\dynatrace\\oneagent\\scripts"

class ScriptState(Enum):
    WAITING = 1
    RUNNING = 2
    ENDED = 3
    TIMEOUT = 4

class ScriptInfo:
    state = ScriptState.WAITING
    nb_minutes_to_wait = 0
    return_code = None
    message = None
    value = None
    value_status = None
    final_message = None
    frequency = None

    def __init__(self, metric_name):
        self.metric_name = metric_name

    def getState(self):
       return self.state
   
    def setState(self, state):
       self.state = state

    def getReturnCode(self):
       return self.return_code
   
    def setReturnCode(self, return_code):
       self.return_code = return_code

    def getMessage(self):
       return self.message
   
    def setMessage(self, message):
       self.message = message

    def getValue(self):
       return self.value
   
    def setValue(self, value):
       self.value = value

    def getValueStatus(self):
       return self.value_status
   
    def setValueStatus(self, value_status):
       self.value_status = value_status

    def getFinalMessage(self):
       return self.final_message
   
    def setFinalMessage(self, final_message):
       self.final_message = final_message

    def getNbMinutesToWait(self):
        return self.nb_minutes_to_wait

    def setNbMinutesToWait(self, nb_minutes_to_wait):
       self.nb_minutes_to_wait = nb_minutes_to_wait

    def getFrequency(self):
       return self.frequency
   
    def setFrequency(self, frequency):
       self.frequency = frequency
    
class SystemCommands(BasePlugin):

    threadPool = None
    
    def initialize(self, **kwargs):

        if self.config["scripts"] == '':
            raise Exception("scripts field cannot be empty")
        else:
            self.scripts = json.loads(self.config["scripts"]).get("scripts")

        for script in self.scripts:
            metricname = script.get('metricname')
            script_info = ScriptInfo(metricname)
            script['script_info'] = script_info
            self.checkFrequency(script)

        debugLogging = self.config["debug"]
        if debugLogging:
            logger.setLevel(logging.DEBUG)
        else:
            logger.setLevel(logging.WARNING)

        if self.threadPool != None:
            self.threadPool.shutdown(wait=False, cancel_futures=True)
            self.threadPool = ThreadPoolExecutor(max_workers=len(self.scripts))
        else:
            self.threadPool = ThreadPoolExecutor(max_workers=len(self.scripts))


    def query(self, **kwargs):
            start = time.time()
        #try:
            value = None
            payload = None

            index = 0
            for script in self.scripts:
                type = script.get('type')
                shell = script.get('shell')
                command = script.get('command')
                timeout = script.get('timeout')
                script_info = script.get('script_info')

                if os.name == 'nt':
                    if not command.startswith(windows_script_directory):
                        raise Exception("Not authorized to execute a command that is not in "+windows_script_directory)
                else:
                    if not command.startswith(linux_script_directory):
                        raise Exception("Not authorized to execute a command that is not in "+linux_script_directory)

                if script_info.getState() == ScriptState.WAITING and script_info.getNbMinutesToWait() == 0:
                    script_info.setNbMinutesToWait(script_info.getFrequency() - 1)
                    script_info.setState(ScriptState.RUNNING)
                    if type == "float":
                        if (shell == ""):
                            self.threadPool.submit(self.float_cmd, command, None , index, timeout)
                        else:
                            self.threadPool.submit(self.float_cmd, command, shell , index, timeout)
                    if type == "status_ko_ok_on_message" or type == "status_ko_ok_on_exit_status" or type == "status_ok_warning_critical":
                        if (shell == ""):
                            self.threadPool.submit(self.run_cmd, command, None , index, timeout)
                        else:
                            self.threadPool.submit(self.run_cmd, command, shell , index, timeout)
                if script_info.getState() == ScriptState.WAITING and script_info.getNbMinutesToWait() >= 1:
                    script_info.setNbMinutesToWait(script_info.getNbMinutesToWait() - 1)
                index = index + 1

            timedelta = time.time() - start
            logger.info('sleeping for '+str(55 - timedelta))
            time.sleep(55 - timedelta)
            for script in self.scripts:
                metricname = script.get('metricname')
                type = script.get('type')
                shell = script.get('shell')
                command = script.get('command')
                timeout = script.get('timeout')
                script_info = script.get('script_info')
                state = script_info.getState()
                if state == ScriptState.RUNNING or state == ScriptState.WAITING:
                    # we send previous value if available
                    if type == "float":
                        self.manage_float_output(script, use_previous_value=True)
                    if type == "status_ko_ok_on_exit_status":
                        self.manage_status_ko_ok_on_exit_status_output(script, use_previous_value=True)
                    if type == "status_ko_ok_on_message":
                        self.manage_status_ko_ok_on_message_output(script, use_previous_value=True)
                    if type == "status_ok_warning_critical":
                        self.manage_status_ok_warning_critical_output(script, use_previous_value=True)

                if state == ScriptState.TIMEOUT:
                    # we send a custom info event, but no value
                    self.results_builder.report_custom_info_event(title="Timeout on "+metricname, description="Timeout "+str(timeout)+" on "+metricname+" with command "+command, entity_selector=FromPluginSelector())
                    script_info.setState(ScriptState.WAITING)

                if state == ScriptState.ENDED:
                    script_info.setState(ScriptState.WAITING)
                    returncode = script_info.getReturnCode()
                    if type == "float":
                        if (returncode == 0):
                            self.manage_float_output(script, use_previous_value=False)
                        else:
                            self.results_builder.report_error_event(title="Execution failed for command "+command, description="Error message is : "+script_info.getMessage(), entity_selector=FromPluginSelector())
                            #raise Exception("Execution failed for command "+command+", error message is : "+script.get('message'))

                    if type == "status_ko_ok_on_exit_status":
                        self.manage_status_ko_ok_on_exit_status_output(script, use_previous_value=False)

                    if type == "status_ko_ok_on_message":
                        if (returncode == 0):
                            self.manage_status_ko_ok_on_message_output(script, use_previous_value=False)
                        else:
                            self.results_builder.report_error_event(title="Execution failed for command "+command, description="Error message is : "+script_info.getMessage(), entity_selector=FromPluginSelector())
                            #raise Exception("Execution of command "+command+" failed with message : "+message)

                    if type == "status_ok_warning_critical":
                        if (returncode == 0):
                            self.manage_status_ok_warning_critical_output(script, use_previous_value=False)
                        else:
                            self.results_builder.report_error_event(title="Execution failed for command "+command, description="Error message is : "+script_info.getMessage(), entity_selector=FromPluginSelector())
                            #raise Exception("Execution of command "+command+" failed with message : "+message)
        #except Exception as e:
        #    logger.error(e)
        #    error = f"system commands - error running commands: {e}"
        #    self.results_builder.report_error_event(error, "System Commands - Error executing")

    def checkFrequency(self, script):
        script_info = script.get('script_info')
        frequency = script.get('frequency')
        if 'm' in frequency:
            cnt = 0
            while frequency[cnt] != 'm':
                cnt = cnt+1
            try:
                minute = int(frequency[0:cnt])
            except Exception:
                raise ConfigException("Invalid frequency value "+frequency+" in json configuration for metric "+script.get('metricname'))
            #script_info.setFrequencyType(FrequencyType.MINUTE)
            script_info.setFrequency(minute)
            script_info.setNbMinutesToWait(0)
        elif 'h' in frequency:
            starttime = script.get('starttime')
            if starttime == None:
                raise ConfigException("starttime field expected in json configuration for metric "+script.get('metricname'))
            cnt = 0
            while frequency[cnt] != 'h':
                cnt = cnt+1
            try:
                hour = int(frequency[0:cnt])
            except Exception:
                raise ConfigException("Invalid frequency value "+frequency+" in json configuration for metric "+script.get('metricname'))
            if ':' in starttime:
                #script_info.setFrequencyType(FrequencyType.HOUR_STARTING_AT_TIME)
                script_info.setFrequency(hour * 60)
                #script_info.setStartTime(starttime)
                # compute the minute in the day when we have to execute the script
                splitted = starttime.split(':')
                try:
                    start_hour = int(splitted[0]) 
                    start_minute = int(splitted[1]) 
                except Exception:
                    raise ConfigException("Invalid frequency value "+frequency+" in json configuration for metric "+script.get('metricname'))
                start_time_in_minutes = (start_hour * 60) + start_minute                
                current_time = datetime.now().strftime("%H:%M")
                splitted = current_time.split(':')
                current_hour = int(splitted[0]) 
                current_minute = int(splitted[1])
                current_time_in_minutes = (current_hour * 60) + current_minute
                if (start_time_in_minutes >= current_time_in_minutes):
                    minutes_to_wait = start_time_in_minutes - current_time_in_minutes
                    script_info.setNbMinutesToWait(minutes_to_wait)
                else:
                    minutes_to_wait = (24*60) + start_time_in_minutes - current_time_in_minutes
                    script_info.setNbMinutesToWait(minutes_to_wait)
            else:
                #script_info.setFrequencyType(FrequencyType.HOUR_STARTING_AT_MINUTE)
                script_info.setFrequency(hour * 60)
                #script_info.setStartMinute(starttime)
                current_time = datetime.now().strftime("%H:%M")
                splitted = current_time.split(':')
                current_minute = int(splitted[1])
                try:
                    start_minute = int(starttime)
                except Exception:
                    raise ConfigException("Invalid frequency value "+frequency+" in json configuration for metric "+script.get('metricname'))
                if (start_minute >= current_minute):
                    minutes_to_wait = start_minute - current_minute
                    script_info.setNbMinutesToWait(minutes_to_wait)
                else:
                    minutes_to_wait = 60 + start_minute - current_minute
                    script_info.setNbMinutesToWait(minutes_to_wait)                   
        elif frequency == 'd':
            starttime = script.get('starttime')
            if starttime == None:
                raise ConfigException("starttime field expected in json configuration for metric "+script.get('metricname'))
            #script_info.setFrequencyType(FrequencyType.DAY)
            script_info.setFrequency(24 * 60)
            #script_info.setStartTime(starttime)
            # compute the minute in the day when we have to execute the script
            splitted = starttime.split(':')
            start_hour = int(splitted[0]) 
            start_minute = int(splitted[1]) 
            start_time_in_minutes = (start_hour * 60) + start_minute                
            current_time = datetime.now().strftime("%H:%M")
            splitted = current_time.split(':')
            current_hour = int(splitted[0]) 
            current_minute = int(splitted[1])
            current_time_in_minutes = (current_hour * 60) + current_minute
            if (start_time_in_minutes >= current_time_in_minutes):
                minutes_to_wait = start_time_in_minutes - current_time_in_minutes
                script_info.setNbMinutesToWait(minutes_to_wait)
            else:
                minutes_to_wait = (24*60) + start_time_in_minutes - current_time_in_minutes
                script_info.setNbMinutesToWait(minutes_to_wait)
        else:
            raise ConfigException("Invalid frequency value "+frequency+" in json configuration for metric "+script.get('metricname'))

    def manage_float_output(self, script, use_previous_value):
        command = script.get('command')
        script_info = script.get('script_info')
        value = script_info.getValue()
        metricname = script.get('metricname')
        if use_previous_value == True:
            if value is not None:
                self.results_builder.add_absolute_result(
                    PluginMeasurement(key="oneagent_system_commands_float_metrics", value=value, dimensions={'metric_name': metricname}, entity_selector=FromPluginSelector())
                )
        else:
            if value is not None:
                logger.info(f'system commands - Reporting metric value "{metricname} {value}"')
                self.results_builder.add_absolute_result(
                     PluginMeasurement(key="oneagent_system_commands_float_metrics", value=value, dimensions={'metric_name': metricname}, entity_selector=FromPluginSelector())
                )
            else:
                self.results_builder.report_error_event(title="returncode is 0, but no value returned for metric "+metricname+" and command = "+command, description="returncode is 0, but no value returned for metric "+metricname+" and command = "+command, entity_selector=FromPluginSelector())
                #raise Exception("returncode is 0, but no value returned for metric "+metricname+" and command = "+command)

    def manage_status_ko_ok_on_exit_status_output(self, script, use_previous_value):
        script_info = script.get('script_info')
        returncode = script_info.getReturnCode()
        metricname = script.get('metricname')
        if (returncode == 0):
            status = "OK"
        else:
            status = "KO"
        if status is not None:
            self.results_builder.state_metric(key="oneagent_system_commands_ok_ko_metrics_on_exit_status", value=status, dimensions={'metric_name': metricname}, entity_selector=FromPluginSelector())
            self.results_builder.add_absolute_result(
               PluginMeasurement(key="oneagent_system_commands_ok_ko_metrics_on_exit_status_alerting", value=returncode, dimensions={'metric_name': metricname}, entity_selector=FromPluginSelector())
            )


    def manage_status_ko_ok_on_message_output(self, script, use_previous_value):
        command = script.get('command')
        metricname = script.get('metricname')
        script_info = script.get('script_info')
        message = script_info.getMessage()
        if use_previous_value == True:
            value = script_info.getValue()
            status = script_info.getValueStatus()
            final_message = script_info.getFinalMessage()
            if status is not None and final_message is not None:
                self.results_builder.state_metric(key="oneagent_system_commands_ok_ko_metrics_on_message", value=status, dimensions={'metric_name': metricname,'message':final_message}, entity_selector=FromPluginSelector())
                self.results_builder.add_absolute_result(
                   PluginMeasurement(key="oneagent_system_commands_ok_ko_metrics_on_message_alerting", value=value, dimensions={'metric_name': metricname,'message':final_message}, entity_selector=FromPluginSelector())
                )
        else:        
            ok_pattern = script.get('ok_pattern')
            ko_pattern = script.get('ko_pattern')
            ok_message = script.get('ok_message')
            ko_message = script.get('ko_message')
            status = None
            value = 0
            final_message = None
            # check ok_pattern
            re_result = re.search(ok_pattern, message)
            if re_result:
                status = "OK"
                value = 0
                cnt = 1
                for group in re_result.groups():
                    if (group != ""):
                        key = "${word"+str(cnt)+"}"
                        ok_message = ok_message.replace(key, group)
                        cnt = cnt + 1
                final_message = ok_message
                script_info.setValue(value)
                script_info.setValueStatus(status)
                script_info.setFinalMessage(final_message)
            else:
                # check ko_pattern
                re_result = re.search(ko_pattern, message)
                if re_result:
                    status = "KO"
                    value = 1
                    cnt = 1
                    for group in re_result.groups():
                        if (group != ""):
                            key = "${word"+str(cnt)+"}"
                            ko_message = ko_message.replace(key, group)
                            cnt = cnt + 1
                    final_message = ko_message
                    script_info.setValue(value)
                    script_info.setValueStatus(status)
                    script_info.setFinalMessage(final_message)
                else:
                    # ok_pattern not found, ko pattern not found : something wrong
                    self.results_builder.report_error_event(title="ok_pattern and ko_pattern not found for command "+command, description="ok_pattern and ko_pattern not found for command "+command+" : there is something wrong with the command", entity_selector=FromPluginSelector())
                    #raise Exception("ok_pattern and ko_pattern not found for command "+command+" : there is something wrong with the command")
            if status is not None and final_message is not None:
                self.results_builder.state_metric(key="oneagent_system_commands_ok_ko_metrics_on_message", value=status, dimensions={'metric_name': metricname,'message':final_message}, entity_selector=FromPluginSelector())
                self.results_builder.add_absolute_result(
                    PluginMeasurement(key="oneagent_system_commands_ok_ko_metrics_on_message_alerting", value=value, dimensions={'metric_name': metricname,'message':final_message}, entity_selector=FromPluginSelector())
                )

    def manage_status_ok_warning_critical_output(self, script, use_previous_value):
        command = script.get('command')
        metricname = script.get('metricname')
        script_info = script.get('script_info')
        message = script_info.getMessage()
        if use_previous_value == True:
            value = script_info.getValue()
            status = script_info.getValueStatus()
            final_message = script_info.getFinalMessage()
            if status is not None and final_message is not None:
                self.results_builder.state_metric(key="oneagent_system_commands_ok_warning_critical_metrics", value=status, dimensions={'metric_name': metricname,'message':final_message}, entity_selector=FromPluginSelector())
                self.results_builder.add_absolute_result(
                    PluginMeasurement(key="oneagent_system_commands_ok_warning_critical_metrics_alerting", value=value, dimensions={'metric_name': metricname,'message':final_message}, entity_selector=FromPluginSelector())
                )
        else:
            ok_pattern = script.get('ok_pattern')
            warning_pattern = script.get('warning_pattern')
            critical_pattern = script.get('critical_pattern')
            ok_message = script.get('ok_message')
            warning_message = script.get('warning_message')
            critical_message = script.get('critical_message')
            status = None
            value = 0
            final_message = None
            # check ok_pattern
            logger.info("message = "+message)
            logger.info("ok_pattern = "+ok_pattern)
            logger.info("warning_pattern = "+warning_pattern)
            logger.info("critical_pattern = "+critical_pattern)
            re_result = re.search(ok_pattern, message)
            if re_result:
                status = "OK"
                value = 0
                cnt = 1
                for group in re_result.groups():
                    key = "${word"+str(cnt)+"}"
                    ok_message = ok_message.replace(key, group)
                    cnt = cnt + 1
                final_message = ok_message
                script_info.setValue(value)
                script_info.setValueStatus(status)
                script_info.setFinalMessage(final_message)
            else:
                # check ko_pattern
                re_result = re.search(warning_pattern, message)
                if re_result:
                    status = "Warning"
                    value = -1
                    cnt = 1
                    for group in re_result.groups():
                        key = "${word"+str(cnt)+"}"
                        warning_message = warning_message.replace(key, group)
                        cnt = cnt + 1
                    final_message = warning_message
                    script_info.setValue(value)
                    script_info.setValueStatus(status)
                    script_info.setFinalMessage(final_message)
                else:
                    # check critical pattern
                    re_result = re.search(critical_pattern, message)
                    if re_result:
                        status = "Critical"
                        value = 1
                        cnt = 1
                        for group in re_result.groups():
                            key = "${word"+str(cnt)+"}"
                            logger.info("key = "+key)
                            logger.info("group = "+group)
                            critical_message = critical_message.replace(key, group)
                            logger.info("critical_message = "+critical_message)
                            cnt = cnt + 1
                        final_message = critical_message
                        script_info.setValue(value)
                        script_info.setValueStatus(status)
                        script_info.setFinalMessage(final_message)
                    else:
                        # ok_pattern not found, warning pattern, critical_pattern not found : something wrong
                        self.results_builder.report_error_event(title="ok_pattern and ko_pattern not found for command "+command, description="ok_pattern and ko_pattern not found for command "+command+" : there is something wrong with the command", entity_selector=FromPluginSelector())
                        #raise Exception("No pattern found for command "+command+" : there is something wrong with the command")
            if status is not None and final_message is not None:
                self.results_builder.state_metric(key="oneagent_system_commands_ok_warning_critical_metrics", value=status, dimensions={'metric_name': metricname,'message':final_message}, entity_selector=FromPluginSelector())
                self.results_builder.add_absolute_result(
                    PluginMeasurement(key="oneagent_system_commands_ok_warning_critical_metrics_alerting", value=value, dimensions={'metric_name': metricname,'message':final_message}, entity_selector=FromPluginSelector())
                )

    def float_cmd(self, cmd, shell, index, timeout):
        script_info = self.scripts[index].get('script_info')
        if shell:
            full_cmd = f"{shell} {cmd}"
        else:
            full_cmd = cmd
        logger.info(f'system commands - Attempting to execute: "{full_cmd}"')
        try:
            result = subprocess.run(full_cmd, stdout=subprocess.PIPE, shell=True, stderr=subprocess.PIPE, timeout=int(timeout))
        except subprocess.TimeoutExpired as e:
            logger.info("Timeout for command "+full_cmd)
            script_info.setReturnCode(0)
            script_info.setMessage('Timeout')
            script_info.setState(ScriptState.TIMEOUT)
            return
        logger.info(f"system commands float cmd - Got: {result} ({result.stdout})")
        if result.returncode != 0:
            script_info.setReturnCode(result.returncode)
            script_info.setMessage(result.stderr.decode())
            script_info.setState(ScriptState.ENDED)
        else:
            script_info.setReturnCode(result.returncode)
            script_info.setValue(locale.atof(result.stdout.decode()))
            script_info.setState(ScriptState.ENDED)

    def run_cmd(self, cmd, shell, index, timeout):
        script_info = self.scripts[index].get('script_info')
        if shell:
            full_cmd = f"{shell} {cmd}"
        else:
            full_cmd = cmd
        logger.info('cmd = '+cmd)
        try:
            result = subprocess.run(full_cmd, stdout=subprocess.PIPE, shell=True, stderr=subprocess.PIPE, timeout=int(timeout))
        except subprocess.TimeoutExpired as e:
            logger.info("Timeout for command "+full_cmd)
            script_info.setReturnCode(0)
            script_info.setMessage('Timeout')
            script_info.setState(ScriptState.TIMEOUT)
            return
        logger.info(f"system commands message_cmd - Got: {result} ({result.stdout})")
        if result.returncode != 0:
            script_info.setReturnCode(result.returncode)
            script_info.setMessage(result.stderr.decode())
            script_info.setState(ScriptState.ENDED)
        else:
            script_info.setReturnCode(result.returncode)
            script_info.setMessage(result.stdout.decode())
            script_info.setState(ScriptState.ENDED)

